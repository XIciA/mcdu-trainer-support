"""Compile a pinned EuroScope snapshot into an offline CDU practice database.

Input files are data, never executed. This imports route geometry, not certified
ARINC 424 procedures. Missing altitude/speed restrictions remain absent.
Run build_airport_catalog.py and build_navigation_details.py first.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMMIT = '951b2f314011e0da116d0f911076b828a8856493'
REPOSITORY = 'https://github.com/Master-Gui-Studio/China-Mainland-Sector'
COORD = re.compile(r'^([NSEW])(\d{3})\.(\d{2})\.(\d{2})\.(\d+)$')
IDENT = re.compile(r'^[A-Z0-9-]{1,10}$')
RWY = re.compile(r'^(0[1-9]|[12][0-9]|3[0-6])[LRC]?$')


def coordinate(text):
    match = COORD.fullmatch(text)
    if not match:
        raise ValueError(f'Invalid coordinate {text}')
    hemi, degree, minute, second, fraction = match.groups()
    degree, minute, second = int(degree), int(minute), float(second + '.' + fraction)
    maximum = 90 if hemi in 'NS' else 180
    if minute >= 60 or second >= 60 or degree + minute / 60 + second / 3600 > maximum:
        raise ValueError(f'Out-of-range coordinate {text}')
    return round((degree + minute / 60 + second / 3600) * (-1 if hemi in 'SW' else 1), 7)


def distance(a, b):
    lat1, lon1, lat2, lon2 = map(math.radians, (*a, *b))
    h = math.sin((lat2-lat1)/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin((lon2-lon1)/2)**2
    return 6371000 * 2 * math.asin(min(1, math.sqrt(h)))


def bearing(a, b):
    p1, l1, p2, l2 = map(math.radians, (*a, *b))
    return round(math.degrees(math.atan2(math.sin(l2-l1)*math.cos(p2), math.cos(p1)*math.sin(p2)-math.sin(p1)*math.cos(p2)*math.cos(l2-l1))) % 360, 2)


def fix(ident, point, kind='WAYPOINT'):
    return dict(ident=ident, name='', kind=kind, latitude=point[0], longitude=point[1])


def position(value):
    return value['latitude'], value['longitude']


def parse_sector(text):
    points = collections.defaultdict(list)
    runways = {}
    geometry = collections.defaultdict(list)
    section, route = '', None
    for raw in text.splitlines():
        line = raw.split(';', 1)[0].strip()
        if not line:
            continue
        if line.startswith('['):
            section, route = line, None
            continue
        columns = line.split()
        if section in ('[FIXES]', '[VOR]', '[NDB]', '[AIRPORT]'):
            coords = [c for c in columns if COORD.fullmatch(c)]
            if len(coords) == 2 and IDENT.fullmatch(columns[0]):
                point = tuple(map(coordinate, coords))
                if point not in points[columns[0]]:
                    points[columns[0]].append(point)
        elif section == '[RUNWAY]' and len(columns) >= 9 and RWY.fullmatch(columns[0]) and RWY.fullmatch(columns[1]):
            a = tuple(map(coordinate, columns[4:6]))
            b = tuple(map(coordinate, columns[6:8]))
            airport = columns[8]
            for ident, start, end in [(columns[0], a, b), (columns[1], b, a)]:
                runways[airport, ident] = dict(airport=airport, ident=ident, latitude=start[0], longitude=start[1],
                                              headingTrue=bearing(start, end), lengthMeters=round(distance(start, end)))
        elif section in ('[SID]', '[STAR]'):
            coords = [c for c in columns if COORD.fullmatch(c)]
            if len(coords) != 4:
                continue
            if not COORD.fullmatch(columns[0]):
                route = columns[0]
            if route:
                geometry[route].append((tuple(map(coordinate, coords[:2])), tuple(map(coordinate, coords[2:]))))
    return points, runways, geometry


def geometry_points(segments):
    result = []
    for a, b in segments:
        if not result:
            result.append(a)
        elif distance(result[-1], a) > 20:
            return []
        result.append(b)
    return result


def resolve_route(tokens, airport_point, local_points, global_points, geometry, kind):
    """Prefer route coordinates when every known point agrees with the drawing.

    Identifiers such as CI01 occur at several airports within a sector, so the
    parser must retain all coordinates until the airport/route is known.
    """
    candidates = []
    for token in tokens:
        local = local_points.get(token, [])
        global_matches = global_points.get(token, [])
        if re.fullmatch(r'(?:DER?|[CF][IF])\d[A-Z0-9]*', token):
            radius = 15000 if token.startswith('DE') else 100000
            local = [p for p in local if distance(p, airport_point) < radius]
            global_matches = [p for p in global_matches if distance(p, airport_point) < radius]
        candidates.append(local or global_matches)
    path = geometry_points(geometry)
    possible = [path] if len(path) == len(tokens) else []
    if len(path) == len(tokens) + 1:
        possible.append(path[1:] if kind == 'SID' else path[:-1])
    for route in possible:
        known = sum(bool(c) for c in candidates)
        if known >= 2 and all(not c or min(distance(p, q) for q in c) < 100 for c, p in zip(candidates, route)):
            return route, [t for t, c in zip(tokens, candidates) if not c]
    if any(not c for c in candidates):
        return None, [t for t, c in zip(tokens, candidates) if not c]
    return [min(c, key=lambda p: distance(p, airport_point)) for c in candidates], []


def leg(value, initial=False):
    return {'type': 'IF' if initial else 'TF', 'fix': value}


def compile_database(source, resources, audit):
    catalog_path = resources / 'china-airports.json'
    catalog = json.loads(catalog_path.read_text())
    airports = {a['icao']: a for a in catalog['airports']}
    data = json.loads((resources / 'navigation-details.json').read_text())
    sectors, global_points, source_files = {}, collections.defaultdict(list), []
    all_runways, cycles = {}, set()
    for path in sorted(source.glob('*/*.sct')):
        content = path.read_bytes()
        text = content.decode('gb18030')
        points, runways, geometry = parse_sector(text)
        sectors[path.stem] = points, runways, geometry
        all_runways.update({key: value for key, value in runways.items() if key[0] in airports})
        for ident, entries in points.items():
            for point in entries:
                if point not in global_points[ident]:
                    global_points[ident].append(point)
        match = re.search(r'AIRAC Cycle\s*:\s*(\d{4})', text)
        if match:
            cycles.add(match[1])
        source_files.append(dict(path=str(path.relative_to(source)), sha256=hashlib.sha256(content).hexdigest()))

    # Sector runways align with the procedure snapshot; do not attach old routes
    # to newly renamed runways from a different airport-data snapshot.
    sector_airports = {airport for airport, _ in all_runways}
    baseline_runways = {(r['airport'], r['ident']): r for r in data['runways'] if r['airport'] not in sector_airports}
    baseline_runways.update(all_runways)
    data['runways'] = sorted(baseline_runways.values(), key=lambda r: (r['airport'], r['ident']))
    groups, approach_paths = collections.defaultdict(list), collections.defaultdict(list)
    failures, recovered, ignored, seen = [], [], collections.Counter(), set()
    for path in sorted(source.glob('*/*.ese')):
        content = path.read_bytes()
        source_files.append(dict(path=str(path.relative_to(source)), sha256=hashlib.sha256(content).hexdigest()))
        points, _, geometry = sectors[path.stem]
        for raw in content.decode('gb18030').splitlines():
            if not raw.startswith(('SID:', 'STAR:')):
                continue
            fields = raw.split(';', 1)[0].split(':', 4)
            if len(fields) != 5:
                continue
            kind, airport, runway, raw_name, route = fields
            if airport not in airports:
                continue
            if raw_name == 'RV':
                ignored['radarVectorPlaceholder'] += 1
                continue
            identity = (kind, airport, runway, raw_name, route)
            if identity in seen:
                ignored['duplicateAcrossSectors'] += 1
                continue
            seen.add(identity)
            row = dict(airport=airport, kind=kind, runway=runway, name=raw_name, source=str(path.relative_to(source)))
            if (airport, runway) not in all_runways:
                failures.append(dict(**row, reason='Runway not in sector snapshot'))
                continue
            tokens = route.strip().split()
            if len(tokens) < 2 or not all(IDENT.fullmatch(t) for t in tokens):
                failures.append(dict(**row, reason='Invalid or insufficient waypoint identifiers'))
                continue
            point = airports[airport]['coordinate']
            coordinates, missing = resolve_route(tokens, (point['latitude'], point['longitude']), points, global_points,
                                                   geometry.get(f'{airport}-{runway}-{raw_name}', []), kind)
            if coordinates is None:
                failures.append(dict(**row, reason='Unresolved waypoints', missing=missing))
                continue
            if missing:
                recovered.append(dict(**row, points=missing, method='Matching sector route drawing'))
            if any(distance(a, b) > 700000 for a, b in zip(coordinates, coordinates[1:])):
                failures.append(dict(**row, reason='Implausible terminal route segment'))
                continue
            values = [fix(t, p) for t, p in zip(tokens, coordinates)]
            # DE/DER is the departure runway end, not a separately entered fix.
            if kind == 'SID' and re.fullmatch(r'DE[R]?'+re.escape(runway), tokens[0]):
                values = values[1:]
            name, _, suffix = raw_name.partition('x')
            row['name'] = name
            if not re.fullmatch(r'[A-Z0-9-]{1,24}', name):
                failures.append(dict(**row, reason='Invalid procedure name'))
                continue
            approach_name = None
            if kind == 'STAR':
                # Split only identifiable terminal CI/FI points. They provide
                # practice geometry, not a validated ARINC approach or minima.
                split = next((i for i, f in enumerate(values) if re.fullmatch(r'[CF][IF]\d[A-Z0-9]*', f['ident'])), None)
                if split is None and suffix.startswith('RNP') and len(values) > 2:
                    split = len(values) - 2
                if split is not None and split > 0:
                    tail = values[split:]
                    marker = re.search(r'[WXYZ]$', tail[-1]['ident'])
                    variant = suffix[3:] if suffix.startswith(('ILS', 'RNP')) else marker[0] if marker else ''
                    approach_name = ('RNP' if suffix.startswith('RNP') else 'ILS') + runway + variant
                    approach_paths[airport, runway, approach_name].append(tail)
                    values = values[:split]
            if not values:
                failures.append(dict(**row, reason='Empty procedure after runway normalization'))
                continue
            groups[airport, kind, runway, name].append((approach_name, values))

    procedures = []
    for (airport, kind, runway, name), routes in sorted(groups.items()):
        unique = {}
        for approach, values in routes:
            key = approach or ''
            if key in unique and unique[key] != values:
                failures.append(dict(airport=airport, kind=kind, runway=runway, name=name,
                                     reason='Conflicting duplicate variant excluded', approach=approach))
                continue
            unique[key] = values
        default = unique[sorted(unique)[0]]
        p = dict(airport=airport, kind=kind, runway=runway, name=name, legs=[leg(v) for v in default])
        if kind == 'STAR' and any(unique):
            p['approachVariants'] = [dict(approach=n, legs=[leg(v) for v in vv]) for n, vv in sorted(unique.items()) if n]
        procedures.append(p)
    for (airport, runway, name), paths in sorted(approach_paths.items()):
        # Retain distinct inbound paths as selectable VIAs, sharing only the
        # final runway leg. These are route-based practice approaches.
        unique = {}
        for path in paths:
            first = path[0]['ident']
            if first in unique and unique[first] != path:
                continue
            unique[first] = path
        rw = all_runways[airport, runway]
        endpoint = fix(airport+runway, position(rw), 'RUNWAY')
        procedures.append(dict(airport=airport, kind='APPROACH', runway=runway, name=name, approachType='RNAV' if name.startswith('RNP') else 'ILS',
                               legs=[leg(endpoint)], vias=[dict(name=n, legs=[leg(v) for v in vv]) for n, vv in sorted(unique.items())]))

    # Publish the same source point coordinates everywhere. Merge near-identical
    # points from duplicated regional extracts, retaining genuinely different
    # same-name fixes so the existing SELECT DESIRED WPT workflow still works.
    fixes = collections.defaultdict(list)
    for value in data['fixes']:
        if value['kind'] != 'WAYPOINT':
            fixes[value['ident']].append(value)
    for p in procedures:
        sections = [p['legs']] + [v['legs'] for v in p.get('vias', [])] + [v['legs'] for v in p.get('approachVariants', [])]
        for entries in sections:
            for entry in entries:
                value = entry['fix']
                if value['kind'] == 'RUNWAY':
                    continue
                existing = next((f for f in fixes[value['ident']] if distance(position(f), position(value)) < 100), None)
                if existing is None:
                    fixes[value['ident']].append(value)
                else:
                    entry['fix'] = existing
    data['fixes'] = sorted((f for values in fixes.values() for f in values), key=lambda f: (f['ident'], f['latitude'], f['longitude']))
    data['procedures'] = sorted(procedures, key=lambda p: (p['airport'], p['kind'], p['runway'], p['name']))
    coverage = {}
    for code, airport in airports.items():
        counts = dict(collections.Counter(p['kind'] for p in procedures if p['airport'] == code))
        coverage[code] = counts
        airport['procedureCoverage'] = 'trainingRoutes' if counts else 'unavailable'
    data['source'] = dict(name='China-Mainland-Sector / CDU practice conversion', url=REPOSITORY+'/tree/'+COMMIT,
                          revision=COMMIT, cycle='/'.join(sorted(cycles)), trainingOnly=True,
                          scope='SID/STAR routes and simplified approach geometry; no certified constraints, missed approaches or airway network.')
    audit.mkdir(parents=True, exist_ok=True)
    report = dict(source=data['source'], files=source_files, coverage=coverage, ignored=dict(ignored),
                  excluded=failures, recovered=recovered, counts=dict(airports=len(airports), runways=len(data['runways']),
                  fixes=len(data['fixes']), procedures=len(procedures)))
    (audit/'community-navigation-conversion.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    (resources/'navigation-details.json').write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':'))+'\n')
    catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'counts':report['counts'], 'excluded':len(failures), 'recovered':len(recovered), 'coverage':coverage}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, default=ROOT/'research/china-navigation-20260926/sector-samples')
    parser.add_argument('--resources', type=Path, default=ROOT/'Sources/MCDUCore/Resources')
    parser.add_argument('--audit', type=Path, default=ROOT/'artifacts/navigation')
    args = parser.parse_args()
    compile_database(args.source, args.resources, args.audit)
